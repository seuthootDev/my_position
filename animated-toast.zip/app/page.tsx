"use client"

import Demo from "../demo"

export default function Page() {
  return <Demo />
}

